export default function App(){
  return (
    <div style={{padding:40,fontFamily:'Arial'}}>
      <h1>TaskGenie-AI ✅</h1>
      <p>Your app built successfully.</p>
      <p><strong>Admin login</strong></p>
      <pre>wills200 / Morgan12</pre>
      <p>Next: add environment variables in Vercel.</p>
    </div>
  );
}
