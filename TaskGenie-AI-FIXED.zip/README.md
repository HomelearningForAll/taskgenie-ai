TASKGENIE-AI (FIXED BUILD)

✅ Vite + Vercel compatible
✅ No code edits required

INSTALL:
1) Upload files to GitHub
2) Deploy on Vercel
3) Add ENV variables
4) Login as admin
